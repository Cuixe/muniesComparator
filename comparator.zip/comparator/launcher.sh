#!/bin/bash

java -jar MuniesComparator-0.0.1-SNAPSHOT.jar